if (strstrt(GPVAL_TERMINALS, 'jpeg') > 0) {set terminal jpeg size 600,223font ",25"
set output './Res92test_lam0.25^_reporter/imageData/_physPressureiT0000030.jpeg'
} else {set terminal png size 600,223font ",25"
set output './Res92test_lam0.25^_reporter/imageData/_physPressureiT0000030.png'
}
set pm3d map
unset key
unset xtics
unset ytics
unset border
set pm3d interpolate 0,0
set lmargin at screen 0
set rmargin at screen 1
set tmargin at screen 0
set bmargin at screen 1
set xlabel "x-axis in m "
set ylabel "y-axis in m "
set cblabel offset 0.5 "physPressure in Pa"
set cbrange [-0.000967864:0.000967864]
set autoscale fix
set palette defined ( 0 "blue", 1 "green", 2 "yellow", 3 "orange", 4 "red" )
splot './Res92test_lam0.25^_reporter/imageData/data/_physPressureiT0000030.matrix' u ($1*0.00210145+-3.33067e-16):($2*0.00210145+0.00543478):3 matrix with pm3d
