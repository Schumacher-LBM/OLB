set key 
set terminal png
set output './test_lam0.25^_reporter/gnuplotData/pressure_hline_0080.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './test_lam0.25^_reporter/gnuplotData/data/pressure_hline_0080.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
