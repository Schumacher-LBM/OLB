set key 
set terminal png
set output './Res96test_lam0.25^_reporter/gnuplotData/pressure_hline_0020.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './Res96test_lam0.25^_reporter/gnuplotData/data/pressure_hline_0020.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
