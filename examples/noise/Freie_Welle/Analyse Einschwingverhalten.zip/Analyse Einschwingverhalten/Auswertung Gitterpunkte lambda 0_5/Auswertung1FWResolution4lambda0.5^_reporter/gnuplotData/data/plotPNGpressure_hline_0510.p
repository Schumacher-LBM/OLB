set key 
set terminal png
set output './Auswertung1FWResolution4lambda0.5^_reporter/gnuplotData/pressure_hline_0510.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './Auswertung1FWResolution4lambda0.5^_reporter/gnuplotData/data/pressure_hline_0510.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
