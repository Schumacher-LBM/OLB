set key 
set terminal png
set output './Auswertung1FWResolution10lambda0.5^_reporter/gnuplotData/pressure_hline_0240.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './Auswertung1FWResolution10lambda0.5^_reporter/gnuplotData/data/pressure_hline_0240.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
