set key 
set terminal png
set output './tmp_test_nw3/gnuplotData/pressure_hline_0100.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './tmp_test_nw3/gnuplotData/data/pressure_hline_0100.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
