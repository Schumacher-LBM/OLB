if (strstrt(GPVAL_TERMINALS, 'jpeg') > 0) {set terminal jpeg size 600,30font ",25"
set output './tmp_test_nw1/imageData/_physPressureiT0000070.jpeg'
} else {set terminal png size 600,30font ",25"
set output './tmp_test_nw1/imageData/_physPressureiT0000070.png'
}
set pm3d map
unset key
unset xtics
unset ytics
unset border
set pm3d interpolate 0,0
set lmargin at screen 0
set rmargin at screen 1
set tmargin at screen 0
set bmargin at screen 1
set xlabel "x-axis in m "
set ylabel "y-axis in m "
set cblabel offset 0.5 "physPressure in Pa"
set cbrange [-0.0375:0.0375]
set autoscale fix
set palette defined ( 0 "blue", 1 "green", 2 "yellow", 3 "orange", 4 "red" )
splot './tmp_test_nw1/imageData/data/_physPressureiT0000070.matrix' u ($1*0.00675+0.025):($2*0.00675+-4.16334e-17):3 matrix with pm3d
