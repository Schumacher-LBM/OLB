set key 
set terminal png
set output './AuswertungFWpython2^_reporter/gnuplotData/pressure_hline_0210.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './AuswertungFWpython2^_reporter/gnuplotData/data/pressure_hline_0210.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
