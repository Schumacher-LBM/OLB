set key 
set terminal png
set output './AuswertungFWpython0.5^_reporter/gnuplotData/pressure_hline_0100.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './AuswertungFWpython0.5^_reporter/gnuplotData/data/pressure_hline_0100.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
