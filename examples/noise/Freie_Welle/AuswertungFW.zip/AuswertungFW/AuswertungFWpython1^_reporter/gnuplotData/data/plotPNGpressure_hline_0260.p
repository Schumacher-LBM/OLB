set key 
set terminal png
set output './AuswertungFWpython1^_reporter/gnuplotData/pressure_hline_0260.png'


set xrange [*:*]
set yrange [*:*]
set xlabel 'distance [m]'
set ylabel 'pressure [PU]'
path = './AuswertungFWpython1^_reporter/gnuplotData/data/pressure_hline_0260.dat'
plot path u (($1)):(($2)) w l t '' lc 1 axis x1y1
